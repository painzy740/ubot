<p align="center">
    <a href="https://github.com/pyrogram/pyrogram">
        <img src="https://docs.pyrogram.org/_static/pyrogram.png" alt="Pyrogram" width="128">
    </a>
    <br>
    <b>Telegram MTProto API Framework for Python</b>
    <br>
    <a href="https://pyrogram.org">
        Homepage
    </a>
    •
    <a href="https://docs.pyrogram.org">
        Documentation
    </a>
    •
    <a href="https://docs.pyrogram.org/releases">
        Releases
    </a>
    •
    <a href="https://t.me/pyrogram">
        News
    </a>
</p>

## Pyrogram
> This Pyrogram code, Recode With BY <a href="https://t.me/rixzbotz">rixzbotz</a>
___________________________________________
## Commad Installer Userbot
```
apt update && apt upgrade -y
```
```
apt install ffmpeg -y
```
```
git clone https://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@github.com/LeXcZxMoDz9/LeXcZUbot69
```
```
cd sevsubotprem=
```
```
screen -S cd sevsubotprem
```
```
bash installnode.sh
```
```
apt install python3-pip
```
```
pip3 install -r requirements.txt
```
```
cp sample.env .env
```
```
nano .env
```
```
bash start.sh
```
