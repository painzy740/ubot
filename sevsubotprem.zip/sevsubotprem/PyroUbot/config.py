import os
from dotenv import load_dotenv

load_dotenv(".env")

MAX_BOT = int(os.getenv("MAX_BOT", "9999"))

DEVS = list(map(int, os.getenv("DEVS", "5942047911").split()))

API_ID = int(os.getenv("API_ID", "28022713"))

API_HASH = os.getenv("API_HASH", "cde7b207b0f715486ff3ac8d23e011e3")

BOT_TOKEN = os.getenv("BOT_TOKEN", "7336831454:AAHzc8rBGo2EqcowXt5xhIgiGSCuD_LDrXY")

OWNER_ID = int(os.getenv("OWNER_ID", "5942047911"))

BLACKLIST_CHAT = list(map(int, os.getenv("BLACKLIST_CHAT", "-1002125842026 -1002053287763 -1002044997044 -1002022625433 -1002050846285").split()))

RMBG_API = os.getenv("RMBG_API", "a6qxsmMJ3CsNo7HyxuKGsP1o")

MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://PainzUbot:PainzUbot2345@bakuzaan.qsum4.mongodb.net/?retryWrites=true&w=majority&appName=bakuzaan")

LOGS_MAKER_UBOT = int(os.getenv("LOGS_MAKER_UBOT","0"))

USER_GROUP = os.getenv("USER_GROUP", "@painzy00")
